export const API_TAG_FAMILY = 'Family';
