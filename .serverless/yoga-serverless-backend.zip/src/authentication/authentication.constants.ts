export const API_TAG_AUTHENTICATION = 'Authentication';
