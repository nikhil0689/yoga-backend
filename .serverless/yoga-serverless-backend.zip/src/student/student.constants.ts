export const API_TAG_STUDENT = 'Student';
