export const API_TAG_DASHBOARD = 'Dashboard';
