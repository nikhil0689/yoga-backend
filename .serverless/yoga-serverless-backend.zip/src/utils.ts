import * as bcrypt from 'bcryptjs';
import secureRandomString from 'secure-random-string';

export const hash = async (data: string): Promise<string> => {
  return bcrypt.hash(data, bcrypt.genSaltSync());
};

export const valueExists = (value: unknown): boolean =>
  value !== null && value !== undefined;

export const genToken = (length = 20): string => {
  return secureRandomString({ length });
};
