export const API_TAG_CLASS = 'Class';
