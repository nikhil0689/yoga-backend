export const API_TAG_PAYMENT = 'Payments';
